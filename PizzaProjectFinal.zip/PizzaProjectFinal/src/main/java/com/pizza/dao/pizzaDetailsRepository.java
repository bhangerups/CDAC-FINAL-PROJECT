package com.pizza.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pizza.entities.pizzaDetails;
@Repository
public interface pizzaDetailsRepository extends JpaRepository<pizzaDetails, Integer>{

}
