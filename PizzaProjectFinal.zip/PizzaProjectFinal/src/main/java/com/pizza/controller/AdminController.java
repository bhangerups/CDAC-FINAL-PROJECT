package com.pizza.controller;

/*
 * import java.security.Principal;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.RequestMapping;
 * 
 * import com.tour.dao.UserRepository; import com.tour.entities.User;
 * 
 * @Controller
 * 
 * @RequestMapping("/admin") public class AdminController {
 * 
 * @Autowired private UserRepository userRepository;
 * 
 * @RequestMapping("/index") public String dashboard(Model model,Principal
 * principal) {
 * 
 * String userName=principal.getName();
 * System.out.println("USERNAME "+userName);
 * 
 * 
 * //get the using username(Email) User user
 * =userRepository.getUserByUserName(userName);
 * System.out.println("ADMIN "+user);
 * 
 * model.addAttribute("user",user);
 * 
 * 
 * return "admin/admin_dashboard"; } }
 */