package com.pizza.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class pizzaDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pizzaId;
	private String pizzaName;
	private String pizzaDetail;

	private String orderId;

	public pizzaDetails(int pizzaId, String pizzaName, String pizzaDetail, String orderId) {
		super();
		this.pizzaId = pizzaId;
		this.pizzaName = pizzaName;
		this.pizzaDetail = pizzaDetail;
		this.orderId = orderId;
	}

	public pizzaDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public String getPizzaDetail() {
		return pizzaDetail;
	}

	public void setPizzaDetail(String pizzaDetail) {
		this.pizzaDetail = pizzaDetail;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "pizzaDetails [pizzaId=" + pizzaId + ", pizzaName=" + pizzaName + ", pizzaDetail=" + pizzaDetail
				+ ", orderId=" + orderId + "]";
	}

}