package com.pizza.entities;




import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;



@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@NotBlank(message = "Name field is required !!")
	@Size(min = 2,max = 20,message ="min 2 and max 20 characters are allowed !!")
	private String name;
	@Column(unique = true)
	@Email(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message="Invalied Email")
	private String email;
	@NotBlank(message = "Mobile field is required !!")
	@Size(min = 10,max = 10,message ="Invalied Mobile no")
	private String mobile;
	@NotBlank(message = "Name field is required !!")
	 @Column(length = 1500, name = "address")
    private String Address;
	

	private String password;
	
	@Column(name="user_type")
	private String role;
	private boolean enable;
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(int id,
			@NotBlank(message = "Name field is required !!") @Size(min = 2, max = 20, message = "min 2 and max 20 characters are allowed !!") String name,
			@Email(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "Invalied Email") String email,
			@NotBlank(message = "Mobile field is required !!") @Size(min = 10, max = 10, message = "Invalied Mobile no") String mobile,
			@NotBlank(message = "Name field is required !!") String address, String password, String role,
			boolean enable) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		Address = address;
		this.password = password;
		this.role = role;
		this.enable = enable;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public boolean isEnable() {
		return enable;
	}


	public void setEnable(boolean enable) {
		this.enable = enable;
	}


	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", mobile=" + mobile + ", Address=" + Address
				+ ", password=" + password + ", role=" + role + ", enable=" + enable + "]";
	}
	

	
	
	
	
}




